-- ═══════════════════════════════════════════
--  GEM QUEST: CRYSTAL KINGDOM
--  Supabase SQL Setup
--  Run this in your Supabase SQL Editor
-- ═══════════════════════════════════════════

-- 1. PROFILES TABLE
-- Extends Supabase's built-in auth.users
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  username TEXT,
  avatar_url TEXT,
  total_score INTEGER DEFAULT 0,
  current_level INTEGER DEFAULT 1,
  lives INTEGER DEFAULT 5,
  lives_last_refill TIMESTAMPTZ DEFAULT NOW(),
  hints_used_today INTEGER DEFAULT 0,
  hints_reset_date DATE DEFAULT CURRENT_DATE,
  streak_count INTEGER DEFAULT 0,
  last_played DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', SPLIT_PART(NEW.email, '@', 1), 'Adventurer'),
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- 2. LEADERBOARD TABLE
CREATE TABLE IF NOT EXISTS public.leaderboard (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  username TEXT NOT NULL DEFAULT 'Adventurer',
  score INTEGER NOT NULL DEFAULT 0,
  level_reached INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure one entry per user (upsert key)
CREATE UNIQUE INDEX IF NOT EXISTS leaderboard_user_unique ON public.leaderboard(user_id);

-- Index for fast score ordering
CREATE INDEX IF NOT EXISTS leaderboard_score_idx ON public.leaderboard(score DESC);


-- 3. LEVELS CACHE TABLE (Gemini-generated levels)
CREATE TABLE IF NOT EXISTS public.levels (
  level_number INTEGER PRIMARY KEY,
  target_score INTEGER NOT NULL DEFAULT 500,
  moves_allowed INTEGER NOT NULL DEFAULT 20,
  difficulty INTEGER DEFAULT 1,
  tip TEXT,
  board_config JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);


-- ═══════════════════════════════════════════
--  ROW LEVEL SECURITY (RLS)
-- ═══════════════════════════════════════════

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leaderboard ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.levels ENABLE ROW LEVEL SECURITY;

-- Profiles: users can read all, update only their own
CREATE POLICY "Profiles are viewable by everyone"
  ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Leaderboard: anyone can read, authenticated can upsert own
CREATE POLICY "Leaderboard viewable by everyone"
  ON public.leaderboard FOR SELECT USING (true);

CREATE POLICY "Users can upsert own leaderboard entry"
  ON public.leaderboard FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own leaderboard entry"
  ON public.leaderboard FOR UPDATE USING (auth.uid() = user_id);

-- Levels: anyone can read, no one can modify from client
CREATE POLICY "Levels readable by everyone"
  ON public.levels FOR SELECT USING (true);

CREATE POLICY "Levels insertable by authenticated"
  ON public.levels FOR INSERT WITH CHECK (auth.role() = 'authenticated');


-- ═══════════════════════════════════════════
--  SEED STARTER LEVELS (first 20)
-- ═══════════════════════════════════════════
INSERT INTO public.levels (level_number, target_score, moves_allowed, difficulty, tip)
VALUES
  (1,  500,  25, 1,  'Look for horizontal rows of matching gems, Your Majesty.'),
  (2,  700,  24, 1,  'Gems at the bottom create chain reactions when matched!'),
  (3,  900,  23, 2,  'Try to set up two matches at once for a combo bonus.'),
  (4,  1200, 22, 2,  'Purple gems are rare — save them for big combos.'),
  (5,  1500, 22, 3,  'Match 4 in a row to forge a mighty Power Gem!'),
  (6,  1900, 21, 3,  'A Power Gem destroys all gems of its color. Use wisely!'),
  (7,  2300, 21, 4,  'Plan two moves ahead to maximize your chain combos.'),
  (8,  2800, 20, 4,  'Matching 5 gems creates a Bomb — it destroys a 3x3 area!'),
  (9,  3300, 20, 5,  'Focus on the center of the board for the most chain reactions.'),
  (10, 4000, 19, 5,  'Boss Level! Chain 3 combos in a row for a massive score boost.'),
  (11, 4600, 19, 5,  'Cyan gems often cluster — target them for quick combos.'),
  (12, 5300, 18, 6,  'A Power Gem activated next to a Bomb is catastrophic — in a good way!'),
  (13, 6000, 18, 6,  'The board favors the patient. Study before you swap.'),
  (14, 6800, 17, 7,  'Red and blue gems appear most often. Master them first.'),
  (15, 7700, 17, 7,  'Vertical combos are easy to miss. Look at columns, not just rows.'),
  (16, 8600, 17, 8,  'A single well-placed Bomb can turn a failing level into victory.'),
  (17, 9500, 16, 8,  'SAGE can reveal hidden moves. Save hints for critical moments.'),
  (18, 10500,16, 9,  'Green gems at the top will fall and may create surprise combos.'),
  (19, 11500,15, 9,  'You are near mastery. Every move must count now.'),
  (20, 12500,15, 10, 'Chapter Boss! Clear the board with at least 5 moves remaining.')
ON CONFLICT (level_number) DO NOTHING;


-- ═══════════════════════════════════════════
--  VERIFY SETUP
-- ═══════════════════════════════════════════
SELECT 'Setup complete!' as status;
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('profiles','leaderboard','levels');

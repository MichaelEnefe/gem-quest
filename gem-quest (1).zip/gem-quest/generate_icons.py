#!/usr/bin/env python3
"""
Generate placeholder PWA icons for Gem Quest.
Run: python3 generate_icons.py
Requires: pip install Pillow
"""

try:
    from PIL import Image, ImageDraw, ImageFont
    import os

    os.makedirs('icons', exist_ok=True)

    sizes = [72, 96, 128, 192, 512]

    for size in sizes:
        img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Dark purple background circle
        margin = size // 10
        draw.ellipse([margin, margin, size-margin, size-margin],
                     fill=(26, 20, 48, 255))

        # Gold ring
        ring_width = max(2, size // 30)
        draw.ellipse([margin, margin, size-margin, size-margin],
                     outline=(245, 200, 66, 255), width=ring_width)

        # Gem emoji approximation - draw a diamond shape
        cx, cy = size // 2, size // 2
        gem_size = size // 3
        points = [
            (cx, cy - gem_size),           # top
            (cx + gem_size, cy),            # right
            (cx, cy + gem_size),            # bottom
            (cx - gem_size, cy),            # left
        ]
        draw.polygon(points, fill=(168, 85, 247, 255))

        # Inner gem highlight
        inner = gem_size // 2
        inner_points = [
            (cx, cy - inner),
            (cx + inner, cy - inner//2),
            (cx, cy),
            (cx - inner, cy - inner//2),
        ]
        draw.polygon(inner_points, fill=(220, 180, 255, 180))

        img.save(f'icons/icon-{size}.png', 'PNG')
        print(f'Created icons/icon-{size}.png')

    # Also create favicon.ico
    img_32 = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img_32)
    draw.ellipse([2, 2, 30, 30], fill=(26, 20, 48, 255))
    draw.ellipse([2, 2, 30, 30], outline=(245, 200, 66, 255), width=2)
    cx, cy = 16, 16
    points = [(cx,cy-8),(cx+8,cy),(cx,cy+8),(cx-8,cy)]
    draw.polygon(points, fill=(168, 85, 247, 255))
    img_32.save('icons/favicon.ico', 'ICO')
    print('Created icons/favicon.ico')

    print('\nAll icons generated successfully!')
    print('Upload the icons/ folder to your GitHub repo.')

except ImportError:
    print("Pillow not installed. Creating SVG placeholder instead...")

    import os
    os.makedirs('icons', exist_ok=True)

    # Create SVG icon that browsers can use
    svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192">
  <rect width="192" height="192" rx="40" fill="#1a1430"/>
  <circle cx="96" cy="96" r="88" fill="none" stroke="#f5c842" stroke-width="4"/>
  <polygon points="96,20 172,96 96,172 20,96" fill="#7c3aed"/>
  <polygon points="96,20 134,58 96,96 58,58" fill="#a855f7"/>
  <polygon points="96,96 134,58 172,96 134,134" fill="#6d28d9"/>
</svg>'''

    with open('icons/icon.svg', 'w') as f:
        f.write(svg)

    # Create simple HTML-based icon notice
    notice = """<!-- ICONS NOTICE
    
Please create PNG icons for the best PWA experience.
Recommended tool: https://realfavicongenerator.net

Required sizes: 72, 96, 128, 192, 512 px
Name format: icon-{size}.png
Place in: /icons/ folder

Quick alternative: Use any online icon generator with the 
gem/diamond theme in purple (#7c3aed) on dark background (#1a1430)
with gold border (#f5c842).
-->"""
    with open('icons/README.html', 'w') as f:
        f.write(notice)

    print("SVG placeholder created at icons/icon.svg")
    print("For production: Generate proper PNG icons at realfavicongenerator.net")

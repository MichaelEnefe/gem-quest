# 💎 Gem Quest: Crystal Kingdom

A polished match-3 puzzle PWA game with AI-powered hints and infinite level generation.

---

## 🚀 Quick Setup (5 Steps)

### Step 1 — Supabase Database
1. Go to your Supabase project dashboard
2. Click **SQL Editor**
3. Paste the entire contents of `supabase_setup.sql`
4. Click **Run**
5. You should see `Setup complete!` ✅

### Step 2 — Supabase Auth
1. In Supabase → **Authentication** → **Providers**
2. Enable **Email** (Magic Link) — already on by default
3. Enable **Discord**:
   - Go to discord.com/developers → New Application → OAuth2
   - Copy Client ID and Client Secret
   - Paste into Supabase Discord provider settings
   - Add redirect URL: `https://YOUR_PROJECT.supabase.co/auth/v1/callback`

### Step 3 — Add Your API Keys
Open `index.html` and find this section near the top of the `<script>` tag:

```javascript
const CONFIG = {
  SUPABASE_URL: 'YOUR_SUPABASE_URL',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY',
  GROQ_KEY: 'YOUR_GROQ_KEY',
  GEMINI_KEY: 'YOUR_GEMINI_KEY',
};
```

Replace with your actual keys:
- **SUPABASE_URL**: Found in Supabase → Settings → API → Project URL
- **SUPABASE_ANON_KEY**: Found in Supabase → Settings → API → anon public key
- **GROQ_KEY**: Your `gsk_...` key from console.groq.com
- **GEMINI_KEY**: Your `AIza...` key from aistudio.google.com

### Step 4 — Icons (Optional but Recommended)
```bash
pip install Pillow
python3 generate_icons.py
```
Or generate icons at: https://realfavicongenerator.net

### Step 5 — Deploy to Netlify
1. Go to **netlify.com**
2. Drag and drop the entire `gem-quest` folder onto the dashboard
3. Your game is live instantly! 🎉

---

## 📁 File Structure
```
gem-quest/
├── index.html          ← Complete game (single file)
├── manifest.json       ← PWA configuration
├── sw.js               ← Service worker (offline support)
├── supabase_setup.sql  ← Database setup (run once)
├── generate_icons.py   ← Icon generator
├── icons/
│   ├── favicon.ico
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-192.png
│   └── icon-512.png
└── README.md
```

---

## 🎮 How to Play
- **Swipe** a gem in any direction to swap with its neighbor
- Match **3+ gems** of the same color to score
- Match **4 in a row** → creates a Power Gem (clears all gems of that color)
- Match **5 or L-shape** → creates a Bomb (3×3 explosion)
- Chain matches for **combo multipliers**
- Use **SAGE** for AI-powered hints (3 per level)

## ⌨️ Controls
| Device | Control |
|--------|---------|
| Mobile | Swipe gem or tap-tap |
| Desktop | Click+drag or click-click |
| Keyboard | Arrow keys + Space/Enter |

---

## 🛠️ Tech Stack
- **Frontend**: Pure HTML5/CSS3/JS (no frameworks)
- **PWA**: Web App Manifest + Service Worker
- **Database**: Supabase (PostgreSQL)
- **Auth**: Supabase Magic Link + Discord OAuth
- **AI Hints**: Groq (llama-3.1-8b-instant)
- **Level Gen**: Google Gemini 2.0 Flash
- **Hosting**: Netlify (free tier)
- **Audio**: Web Audio API (no audio files)
- **Haptics**: Vibration API

---

## 🔑 API Keys — Security Note
The current setup stores API keys in `index.html`. This is fine for development and small-scale deployment. 

For production with many users, move keys to:
- **Netlify Environment Variables** + **Netlify Functions** (free tier available)
- Or **Supabase Edge Functions** (free tier included)

---

## 📱 Install as PWA
- **Android**: Open in Chrome → tap menu → "Add to Home Screen"
- **PC**: Open in Chrome → click install icon in address bar
- **iOS**: Open in Safari → tap share → "Add to Home Screen"

---

## 🗓️ Roadmap
- **Month 1**: Core game ✅, PWA ✅, Auth ✅, AI hints ✅
- **Month 2**: Stripe subscriptions, AdSense ads, premium themes
- **Month 3**: Claude API upgrade, kingdom progression map, social features

---

## 💎 Credits
Built with love using Claude AI.
Powered by Groq, Gemini, and Supabase.
